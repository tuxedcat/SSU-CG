#pragma once
#include <bits/stdc++.h>
#include <stdio.h>
#include <GL/glut.h>
#include <cmath>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
using namespace std;
const double PI = 3.14159265358979323846;